import click
import subprocess
from pathlib import Path

# Correct imports
from forensic_suite_v2.core.engine import Engine
from forensic_suite_v2.core.plugin_loader import load_plugins

BASE = Path(__file__).resolve().parents[2]


@click.group()
def cli():
    """Forensic Suite v2 – Command Line Interface"""
    pass


# ---------------------------
# GUI
# ---------------------------
@cli.command()
def gui():
    """Launch the GUI."""
    from forensic_suite_v2.gui.app import launch_gui
    launch_gui()


# ---------------------------
# Dashboards
# ---------------------------
@cli.group()
def dashboard():
    """Run dashboards."""
    pass


@dashboard.command()
def btc():
    subprocess.Popen([
        "powershell", "-ExecutionPolicy", "Bypass",
        "-File", str(BASE / "dashboards/btc_dashboard.ps1")
    ])


@dashboard.command()
def eth():
    subprocess.Popen([
        "powershell", "-ExecutionPolicy", "Bypass",
        "-File", str(BASE / "dashboards/eth_dashboard.ps1")
    ])


@dashboard.command()
def tron():
    subprocess.Popen([
        "powershell", "-ExecutionPolicy", "Bypass",
        "-File", str(BASE / "dashboards/tron_dashboard.ps1")
    ])


@dashboard.command()
def multi():
    subprocess.Popen([
        "powershell", "-ExecutionPolicy", "Bypass",
        "-File", str(BASE / "dashboards/multi_chain_dashboard.ps1")
    ])


# ---------------------------
# Indexers
# ---------------------------
@cli.command()
@click.option("--chain", required=True, type=click.Choice(["btc", "eth", "tron"]))
def run_indexer(chain):
    """Run a specific indexer."""
    script = BASE / f"scripts/run_{chain}_indexer.ps1"
    subprocess.Popen([
        "powershell", "-ExecutionPolicy", "Bypass",
        "-File", str(script)
    ])


@cli.command()
def run_all():
    """Run all indexers."""
    script = BASE / "run_all_indexers.ps1"
    subprocess.Popen([
        "powershell", "-ExecutionPolicy", "Bypass",
        "-File", str(script)
    ])


# ---------------------------
# Plugins
# ---------------------------
@cli.command()
def plugins():
    """List loaded plugins."""
    engine = Engine()
    load_plugins(engine)
    for name, plugin in engine.plugins.items():
        click.echo(f"{name}: {plugin.description}")


# ---------------------------
# Tracer
# ---------------------------
@cli.command()
@click.argument("chain")
@click.argument("target", required=False)
def trace(chain, target):
    """Run tracer for a chain."""
    engine = Engine()
    load_plugins(engine)
    engine.trace(chain, target)


# ---------------------------
# Health API
# ---------------------------
@cli.command()
def health_api():
    """Run healthcheck HTTP API."""
    import uvicorn
    uvicorn.run("forensic_suite_v2.health.api:app", host="127.0.0.1", port=8080)
