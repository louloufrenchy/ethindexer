"""
Forensic Suite v2 — Unified Multi‑Chain Forensic Platform
"""

from .core.engine import Engine
from .core.plugin_loader import discover_plugins
from .core.logging import get_logger

from .btc_indexer.services.run_btc_indexer_v2 import main as run_btc
from .eth_indexer.services.run_eth_indexer_v2 import main as run_eth
from .tron_indexer.services.run_tron_indexer_v2 import main as run_tron

__all__ = [
    "Engine",
    "discover_plugins",
    "get_logger",
    "run_btc",
    "run_eth",
    "run_tron",
]
