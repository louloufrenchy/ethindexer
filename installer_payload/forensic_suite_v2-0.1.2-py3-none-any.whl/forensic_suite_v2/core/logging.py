import logging
import time
import orjson

class JsonLogger(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        base = {
            "msg": msg,
            "ts": time.time(),
            "component": "core",
        }
        if "extra" in kwargs:
            base.update(kwargs["extra"])
            del kwargs["extra"]
        return orjson.dumps(base).decode(), kwargs

def get_logger(name: str = "forensic_suite"):
    return JsonLogger(logging.getLogger(name), {})
